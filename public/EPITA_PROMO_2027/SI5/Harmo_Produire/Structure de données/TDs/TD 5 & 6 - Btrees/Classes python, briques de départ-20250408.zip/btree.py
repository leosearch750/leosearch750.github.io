# -*- coding: utf-8 -*-
"""BTree Module.

BTree class definition and standard methods and functions.

*Warning:*  Set ``BTree.degree`` before any tree instanciation.

"""

from . import queue
from .queue import Queue


class BTree:
    """BTree class.

    Attributes:
        degree (int): Degree for all existing trees.
        keys (list[Any]): List of node keys.
        children (list[BTree]): List of children.
    """
    
    degree = None

    def __init__(self, keys=None, children=None):
        """BTree instance constructor.

        Args:
            keys (list[Any]).
            children (list[BTree])

        """
        self.keys = keys if keys else []
        self.children = children if children else []

    @property
    def nbkeys(self):
        """Number of keys in node.

        Returns:
            int.
        """
        return len(self.keys)
