# -*- coding: utf-8 -*-
"""
Oct 2019
B-trees - classics: delete to fix
"""

from algopy import btree

# 2.1: min and mx

def minBTree(B):
    '''
    B is not empty
    '''
    while B.children != []:
        B = B.children[0]
    return B.keys[0]
    

def maxBTree(B):
    while B.children:
        B = B.children[B.nbkeys]  # B.children[-1]
    return B.keys[B.nbkeys-1]   # B.keys[-1]
    
# 2.2: Searching


def __binarySearchPos(L, x, left, right):
    if left >= right:
        return right
    else:
        mid = left + (right - left) // 2
        if x == L[mid]:
            return mid
        elif x < L[mid]:
            return __binarySearchPos(L, x, left, mid)
        else:
            return __binarySearchPos(L, x, mid + 1, right)
    
def binarySearchPos(L, x):
    """
    returns the position where x is or might be in L
    """
    return __binarySearchPos(L, x, 0, len(L))

d
###########################################################################            
# deletion
            
#-------------------------------------------------------------------------
# rotations (generalized)

def leftRotation(B, i):
    '''
    makes a rotation from child i+1 to child i
    Conditions: 
    - the tree B exists, 
    - its child i exists and its root is not a 2t-node, 
    - its child i+1 exists and its root is not a t-node.
    '''
    L = B.children[i]
    R = B.children[i+1]


    L.keys.append(B.keys[i])
    B.keys[i] = R.keys.pop(0)
    if R.children:
        L.children.append(R.children.pop(0))


def rightRotation(B, i):
    '''
    makes a rotation from child i-1 to child i
    Conditions: 
    - the tree B exists, 
    - its child i exists and its root is not a 2t-node, 
    - its child i-1 exists and its root is not a t-node.
    '''
    L = B.children[i-1]
    R = B.children[i]

    R.keys.insert(0, B.keys[i-1])
    B.keys[i-1] = L.keys.pop()
    if L.children:
        R.children.insert(0, L.children.pop())

#------------------------------------------------------------------------------
# merge
def merge(B, i):
    '''
    merge B children i and i+1 into child i
    Conditions: 
    - the tree B exists and its root is not a t-node,
    - children i and i+1 exist and their roots are t-nodes.
    '''
    L = B.children[i]
    R = B.children.pop(i+1) #B.children[i+1]
    
    L.keys.append(B.keys.pop(i))
    L.keys += R.keys
    L.children += R.children
            
#-------------------------- delete --------------------------------------------
def __delete(B, x):
    i = binarySearchPos(B.keys, x)
    if B.children == []:
        #FIXME
        pass

        
    else:						# internal node
        if i >= B.nbkeys or B.keys[i] != x:		
            #FIXME
            pass









        
        else: # B.keys[i] == x
            #FIXME
            pass









        

def delete(B, x):
    if B != None:
        __delete(B, x)
        if B.nbkeys > 0:
            return B
        elif B.children:
            return B.children[0]
    return None

