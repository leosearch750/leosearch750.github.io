# -*- coding: utf-8 -*-
"""
B-trees tests
"""


from algopy import btree
import btrees_classics as classics
# import btrees_classics_cor as cor



# split test
def splitTest():
    s = "(<8,18>(<1,4,5>)(<9,10,11,12,13>)(<19, 23>))"
    B = btree.fromlinear(s, 3)
    btree.display(B)
    classics.split(B, 1)
    btree.display(B)


# insertion test


def buildBTreeFromList(L, degree, display = True):
    '''
    build a b-tree: inserts all L elements
    '''
    btree.BTree.degree = degree
    B = None
    for x in L:        
        B = classics.insert(B, x)
        if display :
            print('+', x)
            btree.display(B)
            input()        
    return B

# B = buildBTreeFromList([5, 15, 40, 25, 18, 45, 38, 42, 9], 2)

from random import randint
def buildTest(n, degree, display = False):
    '''
    build a random b-tree of n values with given degree 
    '''
    L = [randint(0, n*5) for i in range(n)]    
    B = buildBTreeFromList(L, degree, display)
    print(btree.isvalid(B))
    L.sort()
#    print(L)
#    print(btree.tolist(B))
    return B


def rotationsTests():
    s = "(<8,18>(<1,4,5>)(<9,10,11,12,13>)(<19, 23>))"
    B = btree.fromlinear(s, 3)
    btree.display(B)
    classics.leftRotation(B,0)
    print("after left rotation")
    btree.display(B)
    classics.rightRotation(B,2)
    print("after right rotation")
    btree.display(B)


def mergeSplitTest():
    s = "(<8,11,18>(<1,4,5>)(<9,10>)(<12,13>)(<19,23>))"
    B = btree.fromlinear(s, 3)
    btree.display(B)    
    classics.merge(B, 1)
    print("after merge children 1 and 2")
    btree.display(B)
    classics.split(B, 1)
    print("after split child 1")
    btree.display(B)
    classics.merge(B, 2)
    print("after merge children 2 and 3")
    btree.display(B)
    
    #---------------------------- alea deletion tests --------------------------
def delTest(n, degree, display = True):
    '''
    build a random b-tree of n values with given degree
    then delete all values!
    '''
    L = [randint(0, n*5) for i in range(n)]    
    B = buildBTreeFromList(L, degree, display = False)
    btree.display(B)
    for x in L:
        B = classics.delete(B, x)
        if display:
            print('-', x)
            if B:
                btree.display(B)
            input()
