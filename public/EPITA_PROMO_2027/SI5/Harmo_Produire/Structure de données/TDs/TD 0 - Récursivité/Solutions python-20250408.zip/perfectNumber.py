# -*- coding: utf-8 -*-
"""
Perfect number
@author: Nathalie
"""

##########################  recursive versions ###############################

def divisors(n, div):
    '''
    Displays proper divisors of n greater than div and returns their sum
    '''
    if div > n // 2:
        return 0
    else:
        if n % div == 0:
            print(div)
            return div + divisors(n, div+1)
        else:
            return divisors(n, div+1)

def perfect(n):
    ''' 
    Displays proper divisors of n
    Tests whether n is perfect
    '''
    print(1)
    return 1 + divisors(n, 2) == n

"""
n = int(input("Give an integer greater than 2: "))
if n < 2:
    print("error")
else:
    print("Divisors:")
    if perfect(n):
        print(n, "is perfect")
    else:
        print(n, "is not perfect")
input("press a key")
"""


# Optimized version (sqrt(n) instead of n/2 calls.)

import math

def divisors2(n, div):
    '''
    Displays proper divisors of n greater than div
    and returns their sum
    '''
    if div * div >= n :
        if div * div == n:
            print(div)
            return div
        else:
            return 0
    else:
        if n % div == 0:
            div2 = n // div            
            print(div)            
            res = div + div2 + divisors2(n, div+1)
            print(div2)
            return res
        else:
            return divisors2(n, div+1)

'''
A nice version (thanks to ???)
'''

def print_ret(n):
    print(n)
    return n
    
def divisors3(n, div):
    '''
    Displays proper divisors of n greater than div
    and returns their sum
    '''
    if div * div >= n :
        if div * div == n:
            return print_ret(div)
        else:
            return 0
    else:
        if n % div == 0:
            div2 = n // div            
            return print_ret(div) + divisors3(n, div+1) + print_ret (div2)
        else:
            return divisors3(n, div+1)


def perfect3(n):
    ''' 
    Displays proper divisors of n
    Tests whether n is perfect
    '''
    print(1)
    return 1 + divisors3(n, 2) == n
