# -*- coding: utf-8 -*-
"""Binary Tree module"""

from queue import Queue


class BinTree:
    """Simple class for binary tree

    Attributes:
        key (Any): Node key.
        left (BinTree): Left child.
        right (BinTree): Right child.

    """

    def __init__(self, key, left, right):
        """Init binary tree.

        Args:
            key (Any): Node key.
            left (BinTree): Left child.
            right (BinTree): Right child.

        """

        self.key = key
        self.left = left
        self.right = right


################ linear representation <-> BinTree

def to_linear_rep(B):
    """
    Return linear representation (str) of BinTree B
    """
    if B == None:
        return "()"
    else:
        return '(' + str(B.key) + to_linear_rep(B.left) + to_linear_rep(B.right) + ')'


def _deserialize_content(content, pos, end, elttype=int):
    """Produce a BinTree from input string.

    Args:
        content (str): String to parse as BinTree.
        pos (int): Current character index in `content`.
        end (int): Length of `content`.

    Returns:
        (BinTree, int): BinTree parsed and next character index to use.

    Raises:
        ExempleSyntaxError: If any format error is encountered.

    """

    # Check missing content
    if pos >= end:
        raise Exception("Unexpected end of content")
    # Check and skip opening parenthesis
    if content[pos] != '(':
        raise Exception("Missing '(' in exemple data")
    pos += 1
    # Check for empty tree
    if content[pos] == ')':
        return None, pos + 1
    # Get BinTree key and create node
    key = ""
    while pos < end and "(" != content[pos] and ")" != content[pos]:
        key += content[pos]
        pos += 1
#    if key == "":
#        raise Exception("Empty key")
    tree = BinTree(elttype(key), None, None)
    # Parse children
    tree.left, pos = _deserialize_content(content, pos, end, elttype)
    tree.right, pos = _deserialize_content(content, pos, end, elttype)
    # Final tree and skip closing parenthesis
    if content[pos] != ')':
        raise Exception("Missing terminal ')' in exemple data")
    return tree, pos + 1


def from_linear_rep(s, elttype=int):
    """
    Build a tree (BinTree) from its linear representation
    optionnal argument: elttype=int gives the type of keys
    """
    return _deserialize_content(s, 0, len(s), elttype)[0]


    
def printBinTree(B, s=""):
    '''
    simple ASCII display tree directory like...
    '''
    if B != None:
        print(s, '- ', B.key)
        printBinTree(B.left, s + "  |")
        printBinTree(B.right, s + "   ")
