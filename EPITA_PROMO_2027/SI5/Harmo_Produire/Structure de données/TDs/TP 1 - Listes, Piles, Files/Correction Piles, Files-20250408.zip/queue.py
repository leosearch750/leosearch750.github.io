"""
Queue static implementation
"""

class Queue:
    def __init__(self, capacity):
        self.capacity = capacity
        self.size = 0
        self.head = 0
        self.elems = [None] * capacity

def enqueue(queue, elm):
    if queue.size >= queue.capacity:
        return False

    queue.elems[(queue.head + queue.size) % queue.capacity] = elm
    queue.size += 1
    return True

def dequeue(queue):
    if queue.size < 1:
        return None

    result = queue.elems[queue.head]
    queue.head = (queue.head + 1) % queue.capacity
    queue.size -= 1
    return result
