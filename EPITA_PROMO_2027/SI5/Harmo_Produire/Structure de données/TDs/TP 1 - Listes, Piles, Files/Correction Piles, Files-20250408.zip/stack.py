"""
Stack static implementation
"""

class Stack:
    def __init__(self, capacity):
        self.capacity = capacity
        self.top = 0
        self.elems = [None] * capacity

def push(stack, elm):
    if stack.top >= stack.capacity:
        return False

    stack.elems[stack.top] = elm
    stack.top += 1
    return True

def pop(stack):
    if stack.top == 0:
        return None

    stack.top -= 1
    return stack.elems[stack.top]

def is_empty(stack):
    return stack.top == 0
