class LinkedList:
    def __init__(self, val):
        self.elem = val
        self.next = None

def pretty_print(L):
    if L is not None:
        cursor = L
        print(L.elem, end="")
        cursor = cursor.next
        while cursor != None:
            print(f" -> {cursor.elem}", end="")
            cursor = cursor.next
    print()

def prepend(L, val):
    new_head = LinkedList(val)
    new_head.next = L
    return new_head

"""
Stack dynamic implementation
"""

def push(stack, val):
    return prepend(stack, val)

def pop(stack):
    if stack == None:
        return None, None

    result = stack.elem
    stack = stack.next
    return stack, result

def is_empty(stack):
    return stack == None
