class LinkedList:
    def __init__(self, val):
        self.elem = val
        self.next = None

"""
Queue dynamic implementation
"""

def enqueue(queue, val):
    node = LinkedList(val)

    if queue == None:
        # circular list
        node.next = node
        return node

    node.next = queue.next
    queue.next = node
    return node


def dequeue(queue):
    if queue == None:
        return None, None

    first = queue.next
    result = first.elem

    # last element
    if queue.next is queue:
        return None, result

    queue.next = first.next
    return queue, result


def print_queue(L):
    if L is not None:
        first = L.next
        print(first.elem, end='')
        node = first
        while node.next is not first:
            node = node.next
            print(f" -> {node.elem}", end='')
    print()
