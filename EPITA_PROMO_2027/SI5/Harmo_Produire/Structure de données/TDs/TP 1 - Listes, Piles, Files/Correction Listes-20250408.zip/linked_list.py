class LinkedList:
    def __init__(self, val):
        self.elem = val
        self.next = None

def prepend(L, val):
    new_head = LinkedList(val)
    new_head.next = L
    return new_head

def append(L, val):
    if L is None:
        return LinkedList(val)
    cursor = L
    while cursor.next != None:
        cursor = cursor.next
    cursor.next = LinkedList(val)
    return L

def print_list(L):
    if L is not None:
        cursor = L
        print(L.elem, end="")
        cursor = cursor.next
        while cursor != None:
            print(f" -> {cursor.elem}", end="")
            cursor = cursor.next
    print()

def list_from(l):
    if l == []:
        return None
    L = LinkedList(l[len(l) - 1])
    for i in range(1, len(l)):
        L = prepend(L, l[len(l) - 1 - i])
    return L

def delete(L, val):
    cursor = L

    if cursor != None and cursor.elem == val:
        L = cursor.next
        return L, True

    while cursor != None:
        if cursor.elem == val:
            prev.next = cursor.next
            cursor = None
            return L, True
        prev = cursor
        cursor = cursor.next

    return L, False
