def count(x, L):
    cpt = 0
    for e in L:
        if e == x:
            cpt = cpt + 1
    return cpt

def is_present(x, L):
    for i in range(len(L)):
        if L[i] == x:
            return True
    return False

def delete_at(L, k):
    # L.pop(k)
    if k >= len(L):
        return False
    for i in range(k, len(L) - 1):
        L[i] = L[i + 1]
    L.pop()
    return True

def insert_at(L, k, e):
    # L.insert(k, e)
    if k > len(L):
        return False
    L.append(None)
    i = len(L)-1
    while i > k:
        L[i] = L[i-1]
        i = i - 1
    L[k] = e
    return True

import math

def eratosthenes(n):
    prime = []
    for i in range(n + 1):
        prime.append(True)

    for i in range(2, int(math.sqrt(n)) + 1):
        if prime[i]:
            for j in range(i * i, n + 1, i):
                prime[j] = False

    L = []
    for i in range(2, n + 1):
        if prime[i]:
            L.append(i)
    return L
