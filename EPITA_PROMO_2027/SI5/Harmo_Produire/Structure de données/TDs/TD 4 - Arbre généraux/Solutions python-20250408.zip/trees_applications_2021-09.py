# -*- coding: utf-8 -*-
"""
Sept. 2021
S3 - trees applications
"""

from algopy import tree, treeasbin
from algopy import queue

'''
tree -> list representation
'''

def tree_to_list(T):
    s = '(' + str(T.key)
    for child in T.children:
        s += tree_to_list(child)
    s += ')'
    return s

def treeAsBin_to_list(B):
    s = '(' + str(B.key)
    C = B.child
    while C != None:
        s += treeAsBin_to_list(C)
        C = C.sibling
    s += ')'
    return s
    


"""
tree -> dot
"""

# warning: the following versions do not work if keys are not unique 
# see algopy/tree.py for a version that uses id

def dot(T):
    """Write down dot format of tree.

    Args:
        T (Tree).

    Returns:
        str: String storing dot format of tree.

    """

    s = "graph {\n"
    q = queue.Queue()
    q.enqueue(T)
    while not q.isempty():
        T = q.dequeue()
        for child in T.children:
            s = s + "   " + str(T.key) + " -- " + str(child.key) + "\n"
            q.enqueue(child)
    s += "}"
    return s

def dotBin(B):
    """Write down dot format of tree.

    Args:
        B (TreeAsBin).

    Returns:
        str: String storing dot format of tree.

    """

    s = "graph {\n"
    q = queue.Queue()
    q.enqueue(B)
    while not q.isempty():
        B = q.dequeue()
        C = B.child
        while C:
            s = s + "   " + str(B.key) + " -- " + str(C.key) + "\n"
            q.enqueue(C)
            C = C.sibling
    s += "}"
    return s

"""
3.3 find_sum(B, sum) tests if there exists a branch in the tree B (TreeAsBin)
such that the sum of its values (integers) is equal to Sum
"""

# with return in loop :o
   
def find_sum(B, Sum, s=0):
    """
    B: TreeAsBin
    optional parameter s is the sum of values in current path from root to parent of B root
    """
    if B.child == None:
        return s + B.key == Sum
    else:
        C = B.child
        while C:
            if find_sum(C, Sum, s + B.key):
                return True
            C = C.sibling
        return False

# without return in loop, without optional parameter
   
def find_sum2(B, Sum):
    """
    B: TreeAsBin
    """
    if B.child == None:
        return B.key == Sum
    else:
        found = False
        C = B.child
        while C != None and not found:
            found = find_sum2(C, Sum - B.key)
            C = C.sibling
        return found

# without found
def find_sum3(B, Sum):
    """
    B: TreeAsBin
    """
    if B.child == None:
        return B.key == Sum
    else:
        C = B.child
        while C != None and not find_sum3(C, Sum - B.key):
            C = C.sibling
        return C != None        

# using the "binary structure"

def find_sum_bin(B, Sum):
    if B.child == None:
        if B.key == Sum:
            return True
    else:
        if find_sum_bin(B.child, Sum - B.key):
            return True
    return B.sibling != None and find_sum_bin(B.sibling, Sum)
            




# Average External Depth (Profondeur moyenne externe)

def __average_external_depth(T, depth=0):
    if T.nbchildren == 0:
        return (depth, 1)
    else:
        depthsum = 0
        nbl = 0
        for i in range(T.nbchildren):
            (s, n) = __average_external_depth(T.children[i], depth + 1)
            depthsum += s
            nbl += n
        return (depthsum, nbl)

def average_external_depth(T):
    (epl, nbl) = __average_external_depth(T)  
    return epl / nbl


def __average_external_depth_bin(B, depth=0):
    if B.child == None:
        return (depth, 1)
    else:
        depthsum = 0
        nbl = 0
        C = B.child
        while C:
            (s, n) = __average_external_depth_bin(C, depth + 1)
            depthsum += s
            nbl += n
            C = C.sibling
        return (depthsum, nbl)

def average_external_depth_bin(B):
    """
    B: TreeAsBin
    """
    (epl, nbl) = __average_external_depth_bin(B)  
    return epl / nbl
           
def __average_external_depth_bin2(B, depth=0):
     if B.child:    # if B.child != None
         (depthsum, nbl) = __average_external_depth_bin2(B.child, depth + 1)
     else:
         (depthsum, nbl) = (depth, 1)
     if B.sibling:
        (s, n) = __average_external_depth_bin2(B.sibling, depth)
        depthsum += s
        nbl += n
     return (depthsum, nbl)

def average_external_depth_bin2(B):
    """
    B: TreeAsBin
    """
    (epl, nbl) = __average_external_depth_bin2(B)
    return epl / nbl

     
"""
equality Tree & TreeAsBin
"""

# with return in loop
def same(T, B):
    if T.key != B.key:
        return False
    else:
        Bchild = B.child
        for Tchild in T.children:
            if Bchild == None or not(same(Tchild, Bchild)):
                return False
            Bchild = Bchild.sibling
    return Bchild == None

def same2(T, B):
    if B.key != T.key:
        return False
    i = 0
    C = B.child
    while i < T.nbchildren and C != None:
        if not same2(T.children[i], C):
            return False
        i += 1
        C = C.sibling
    return C == None and i == T.nbchildren

# without return in the loop
def same3(T, B):
    if T.key != B.key:
         return False
    else:
         Bchild = B.child
         i = 0
         while i < T.nbchildren and Bchild and same3(T.children[i], Bchild):
             i += 1
             Bchild = Bchild.sibling
         return i == T.nbchildren and Bchild == None
         


"""
TreeAsBin -> Tree
"""

def treeasbin_to_tree(B):
    T = tree.Tree(B.key, [])
    child = B.child
    while child != None:
        T.children.append(treeasbin_to_tree(child))
        child = child.sibling
    return T


    
"""
Tree -> TreeAsBin
"""

def tree_to_treeasbin_(T):
    B = treeasbin.TreeAsBin(T.key, None, None)
    if T.nbchildren != 0:
        B.child = tree_to_treeasbin(T.children[0])
        last = B.child
        for i in range(1, T.nbchildren):    
            last.sibling = tree_to_treeasbin_(T.children[i])
            last = last.sibling
    return B

def tree_to_treeasbin(T):
    B = treeasbin.TreeAsBin(T.key, None, None)
    firstchild = None
    for i in range(T.nbchildren-1, -1, -1):
        C = tree_to_treeasbin(T.children[i])
        C.sibling = firstchild
        firstchild = C
    
    B.child = firstchild
    return B



"""
"linear representation" -> Tree (int keys)
The string is assumed correct!
"""

def __from_linear(s, i=0): 
        i += 1 # to skip the '('
        key = ""
        while s[i] != '(' and s[i] != ')':  # s[i] not in "()"
            key += s[i]
            i += 1
        T = tree.Tree(int(key), [])
        while s[i] != ')':  # s[i] == '('
            (C, i) = __from_linear(s, i)
            T.children.append(C)
        i += 1 # to skip the ')'
        return (T, i)

def from_linear(s):
    (T, _) = __from_linear(s)
    return T


