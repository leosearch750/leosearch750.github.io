# -*- coding: utf-8 -*-
"""General Tree module.

*Warning:* All the functions defined in this module are assumed to receive a non-None
value for their ``ref/T`` parameter.

"""

from . import queue
from .queue import Queue


class Tree:
    """Simple class for general tree.

    Attributes:
        key (Any): Node key.
        children (List[Tree]): Node children.

    """

    def __init__(self, key=None, children=None):
        """Init general tree, ensure children are properly set.

        Args:
            key (Any).
            children (List[Tree]).

        """

        self.key = key

        if children == None:
            self.children = []
        else:
            self.children = children

    @property
    def nbchildren(self):
        """Number of children of node."""

        return len(self.children)
