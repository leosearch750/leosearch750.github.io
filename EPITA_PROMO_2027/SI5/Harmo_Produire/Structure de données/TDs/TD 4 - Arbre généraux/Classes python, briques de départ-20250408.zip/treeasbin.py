# -*- coding: utf-8 -*-
"""General Tree module: first child - right sibling representation.

*Warning:* All the functions defined in this module are assumed to receive a non-None
value for their ``ref`` parameter.

"""

from . import queue
from .queue import Queue

class TreeAsBin:
    """
    Simple class for (General) Trees 
    represented as Binary Trees (first child - right sibling)
    """

    def __init__(self, key, child=None, sibling=None):
        """
        Init Tree
        """
        self.key = key
        self.child = child
        self.sibling = sibling
