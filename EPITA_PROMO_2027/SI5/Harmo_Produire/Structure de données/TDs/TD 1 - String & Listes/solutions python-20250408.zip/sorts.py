#SelectionSort

def minimum(L, d, f):
    '''
    L: list
    d, f: the list L is considered between the indexes d and f included
    returns the position of the minimum of L considering the positions in [d, f]
    '''
    pos = d
    for i in range(d + 1, f + 1):
        if L[i] < L[pos]:
            pos = i
    return pos

def minimum2(L, d, f):
    '''
    L: list
    d, f: the list L is considered between the indexes d and f included
    returns the position of the minimum of L considering the positions in [d, f]
    '''
    while d < f:
        if L[d] < L[f]:
            f = f - 1
        else:
            d = d + 1
    return d

def select_sort(L):
    '''
    L: list
    sorts the list L in increasing order (in-place)
    '''
    n = len(L) - 1
    for i in range(n):
        m = minimum(L, i, n)
        L[m], L[i] = L[i], L[m]

#InsertionSort

def insert(L, x):
    '''
    L: list
    x: element
    inserts element x in the sorted list L
    '''
    i = 0
    l = len(L)
    while i < l and x > L[i]:
        i = i + 1
    L.append(None)
    for k in range(l, i, -1):
        L[k] = L[k - 1]
    L[i] = x

def insertion_sort(L):
    '''
    L: list
    sorts the list L in increasing order (not in-place)
    '''
    res = []
    for e in L:
        insert(res, e)
    return res

def insertion_sort2(L):
    '''
    L: list
    sorts the list L in increasing order (in-place)
    '''
    for i in range(len(L)):
        ind = i
        while ind > 0 and L[ind - 1] > L[ind]:
            tmp = L[ind - 1]
            L[ind - 1] = L[ind]
            L[ind] = tmp
            ind = ind - 1

def insertion_sort3(L):
    '''
    L: list
    sorts the list L in increasing order (in-place)
    '''
    for i in range(len(L)):
        x = L[i]
        j = i - 1
        while j >= 0 and x < L[j]:
            L[j + 1] = L[j]
            j = j - 1
        L[j + 1] = x

# BubbleSort

def bubble_sort(L):
    '''
    L: list
    sorts the list L in increasing order (in-place)
    '''
    swap = True
    n = len(L)
    while swap:
        swap = False
        for i in range(n - 1):
            if L[i] > L[i + 1]:
                (L[i], L[i + 1]) = (L[i + 1], L[i])
                swap = True
        n = n - 1

def bubble_sort2(L):
    '''
    L: list
    sorts the list L in increasing order (in-place)
    '''
    n = len(L)
    change = 1
    while change != 0:
        change = 0
        for i in range(n - 1):
            if L[i] > L[i + 1]:
                 (L[i], L[i + 1]) = (L[i + 1], L[i])
                 change = i + 1
        n = change

# MergeSort

def partition(L):
    '''
    L: list
    splits L into two (new) lists of almost identical lengths
    and returns them
    '''
    n = len(L)
    L1 = []
    for i in range(0, n//2):
        L1.append(L[i])
    L2 = []
    for i in range(n//2, n):
        L2.append(L[i])
    return (L1, L2)

def merge(L1, L2):
    '''
    L1: sorted list
    L2: sorted list
    merges two lists L1 and L2, sorted in increasing order,
    into one new sorted list.
    '''
    R = []
    i = 0
    j = 0
    n1 = len(L1)
    n2 = len(L2)
    while i < n1 and j < n2:
        if L1[i] <= L2[j]:
            R.append(L1[i])
            i = i + 1
        else:
            R.append(L2[j])
            j = j + 1
    for i in range(i, n1):
        R.append(L1[i])
    for j in range(j, n2):
        R.append(L2[j])
    return R

def merge2(L1, L2):
    '''
    L1: sorted list
    L2: sorted list
    merges two lists L1 and L2, sorted in increasing order,
    into one new sorted list.
    '''
    R = []
    n1 = len(L1)
    n2 = len(L2)
    (i1, i2) = (0, 0)
    for i in range(n1 + n2):
        if (i2 == n2) or (i1 < n1 and L1[i1] <= L2[i2]):
            R.append(L1[i1])
            i1 = i1 + 1
        else:
            R.append(L2[i2])
            i2 = i2 + 1
    return R

def merge_sort(L):
    '''
    L: list
    sorts the list L not in place
    '''
    if len(L) <= 1:
        return L
    else:
        (L1, L2) = partition(L)
        return merge(merge_sort(L1), merge_sort(L2))

# QuickSort (pas dans la feuille TD, mais bonus intéressant)

def partition_p(L, left, right):
    '''
    L: list
    left, right: 0 <= left < right <= len(L)
    in L[left, right[ moves all values smaller than
    mid point (pivot) in the left part
    and higher value in the right part
    returns the new position of the pivot
    '''
    pivot = left + (right - left) // 2
    pval = L[pivot]
    (L[pivot], L[right - 1]) = (L[right - 1], L[pivot])
    pivot = left
    for i in range(left, right - 1):
        if L[i] <= pval:
            (L[pivot], L[i]) = (L[i], L[pivot])
            pivot = pivot + 1
    (L[pivot], L[right - 1]) = (L[right - 1], L[pivot])
    return pivot

def qsort(L, left, right):
    '''
    L: list
    left, right: 0 <= left <= right <= len(L)
    sorts in place the sublist L[left, right[
    (between positions left included and right not included)
    '''
    if right - left > 1:
        pivot = partition_p(L, left, right)
        qsort(L, left, pivot)
        qsort(L, pivot + 1, right)

def quick_sort(L):
    '''
    L: list
    sorts the list L in place
    '''
    qsort(L, 0, len(L))

